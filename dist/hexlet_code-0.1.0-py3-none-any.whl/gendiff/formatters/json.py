import json


def get_json(data):
    return json.dumps(data, indent=4)
